﻿using UnityEngine;
using System.Collections;
using System.IO;
using System.Collections.Generic;

public class DoorReplication : MonoBehaviour {

	DirectoryInfo directory = new DirectoryInfo("/storage/emulated/0");
	string rootFolderPath = "C:\\Users\\Snow_Leopard\\Downloads";
	//string rootFolderPath = "/storage/emulated/0";
	bool isUsedFirst = false;
	bool isUsedAgain = false;

	public float vRadius = 5.0f;
	public GameObject door;
	public GameObject shelf;
	public GameObject corridor;
	public int filePerShelf = 5;
	public float sepLimit  = 1.5f;

	private float lastClickTime;	
	private float catchTime;
	private int travelButton;	
	private float navigationSpeed;
	private int backButton;
	private static string currentStringPath = "";
	private static Vector3 navigationTransformPosition = new Vector3(0,0,0);	
	private static Vector3 mainCameraTransformPosition = new Vector3(0,0,0);
	private static int backButtonCounter;
	private static int travelButtonCounter;
	private static List<string> listDirectories = new List<string>();	
	private static List<string> listFiles = new List<string>();

	string[] dirs = null;
	string[] files = null;

	Vector3 leftWallRotation = new Vector3(0.0f,0.0f,1.0f);
	Vector3[] fileLocations = null;
	Vector3[] doorLocations = null;
	Vector3[] corridorLocations = null;
	Vector3[] shelfLocations = null;

	Dictionary<int,GameObject> nearDoors = new Dictionary<int,GameObject>();
	Dictionary<int,GameObject> nearCorridors = new Dictionary<int,GameObject>();
	Dictionary<int,GameObject> nearShelfs = new Dictionary<int,GameObject>();

	Vector3 door1Ref = new Vector3 (-0.668f, 0.31f, -2.981f);
	Vector3 door2Ref = new Vector3 (-0.668f, 0.31f, 2.63f);
	Vector3 shelfRef = new Vector3 (-0.643f, 0.061f, 2.198f);

	List<GameObject> presentObject = new List<GameObject>();

	// Use this for initialization
	void Start () {

		backButtonCounter = 0;

		travelButtonCounter = 0;

		lastClickTime = 0.0f;
		
		catchTime = 0.01f;

		travelButton = 0;

		backButton = 1;

		navigationSpeed = 0.02f;

		listDirectories.Add(this.rootFolderPath);
		
		listFiles.Add(this.rootFolderPath);

		setInitialPosition();

		generateSceneVariables ();

		setObjectLocations ();
		//check ();

	
	}
	
	// Update is called once per frame
	void Update () {

		// Get the current gaze direction from the Main Camera 
		Quaternion gazeDirection = GameObject.Find("Main Camera").transform.localRotation;
		
		string gameObjectName = onRaycasting();

		Debug.Log (gameObjectName);

		Debug.Log (listDirectories[listDirectories.Count - 1]);

		Debug.Log (listFiles[listFiles.Count - 1]);

		Debug.Log (this.rootFolderPath);

		Debug.Log (isUsedFirst + " " + isUsedAgain);


		// Back Button Event
		if(Input.GetMouseButton(backButton)){

			// Counter is added to restrict the execution of this code snippet to only once even after multiple frame shift 
			// for only one right mouse click
			if(listDirectories.Count != 1 &&
			   backButtonCounter < 1){

				removeAllObjects(this.nearCorridors);

				removeAllObjects(this.nearDoors);

				removeAllObjects(this.nearShelfs);

				listDirectories.RemoveAt(listDirectories.Count - 1);

				listFiles.RemoveAt(listFiles.Count - 1);

				this.rootFolderPath = listDirectories[listDirectories.Count - 1];

				generateSceneVariables ();
				
				setObjectLocations ();

				getInitialPosition();

				manageObjects ();

				backButtonCounter++;

			}

		} else {

			// Single Mouse Click
			if(Input.GetMouseButton(travelButton)){

				// Initializing the back counter variable to launch at the right click event or back button event
				if(backButtonCounter != 0){
					
					backButtonCounter = 0;
					
				}

				if(gameObjectName != "null"){
						
					if(GameObject.Find (gameObjectName).transform.tag == "Navigate"){
														
						if(Directory.GetFiles(gameObjectName).Length > 0 ||
							   Directory.GetDirectories(gameObjectName).Length > 0){

								if(isUsedFirst){

									if(!isUsedAgain){

										isUsedAgain = true;

										this.rootFolderPath = gameObjectName;
										
										listDirectories.Add(this.rootFolderPath);
										
										listFiles.Add(this.rootFolderPath);
														
										getInitialPosition();

										generateSceneVariables ();
										
										setObjectLocations ();

										manageObjects ();

									    isUsedFirst = false;

										isUsedAgain = false;

									}


								} else {

									isUsedFirst = true;

									GameObject.Find (gameObjectName).transform.GetComponentInChildren<TextMesh>().color = Color.blue;

								}
								
							}
							
						} else {

							isUsedFirst = false;

							onTravel(gazeDirection, navigationSpeed);
							
							manageObjects ();

						}
						
					} else {

						onTravel(gazeDirection, navigationSpeed);
						
						manageObjects ();

					}


			}


		}


	
	}

	void generateSceneVariables(){

		this.dirs = Directory.GetDirectories (this.rootFolderPath);
		this.files = Directory.GetFiles (this.rootFolderPath);

	}

	void setObjectLocations()
	
	{
		this.shelfLocations = new Vector3[Mathf.CeilToInt(this.files.Length*1.0f/this.filePerShelf)];

		int i = 0;
		for (; i < this.shelfLocations.Length; i++) {
			this.shelfLocations [i] = new Vector3 (this.shelfRef.x - (i)*sepLimit, this.shelfRef.y, this.shelfRef.z);

		}

		this.doorLocations = new Vector3[this.dirs.Length];

		int numFoldersLeft = 0; 
		if (this.dirs.Length % 2 == 0)
			numFoldersLeft = this.dirs.Length / 2;
		else
			numFoldersLeft = this.dirs.Length / 2 + 1;
		int numFoldersRight = Mathf.FloorToInt(this.dirs.Length);

		int j = 0;
		for (; j< this.dirs.Length/2; j++)
			this.doorLocations [j] = new Vector3 (this.door1Ref.x + (j + 1) *sepLimit, this.door1Ref.y, this.door1Ref.z);

		for (int k = 0; j < this.dirs.Length; j++,k++)
			this.doorLocations [j] = new Vector3 (this.door2Ref.x + (k + 1) * sepLimit, this.door2Ref.y, this.door2Ref.z);


		this.corridorLocations = new Vector3[this.dirs.Length / 2 + 1 + Mathf.CeilToInt(this.files.Length*1.0f/this.filePerShelf)];

		int m = 0;
		for (; m<Mathf.CeilToInt(this.files.Length*1.0f/this.filePerShelf); m++) {
			this.corridorLocations [m] = new Vector3 (-m * sepLimit, 0.0f, 0.0f);
		}

		for (int k = 1; k <= this.dirs.Length/2 + 1; m++,k++) {
			this.corridorLocations[m] = new Vector3(k*sepLimit , 0.0f , 0.0f);
		}

		// Last Shelf and Door Position

		//if(this.doorLocations == null)

	}

	void check(){

		foreach(Vector3 loc in this.corridorLocations){
			Instantiate(this.corridor,loc,Quaternion.identity);
		}

		foreach (Vector3 loc in this.doorLocations) {
			Instantiate(this.door, loc,Quaternion.identity);
		}
		if(this.shelfLocations != null)
		foreach (Vector3 loc in this.shelfLocations) {
			Instantiate(this.shelf, loc,Quaternion.identity);
		}
	
	}



	List<int> getNearLocations(Vector3[] loc)
	
	{
		List<int> l = new List<int> ();

		if (loc == null)
			return l;

		for (int i = 0; i < loc.Length; i++) {
			if ((GameObject.Find ("Main Camera").transform.position - loc [i]).magnitude <= this.vRadius)
				l.Add (i);
		}
		return l;

	}

	Dictionary<int,GameObject> removeFarObjects(Dictionary<int,GameObject> pObj)
	{
		List<int> l = new List<int> ();
		foreach (KeyValuePair<int,GameObject> k in pObj) {
			if ((GameObject.Find ("Main Camera").transform.position - k.Value.transform.position).magnitude > this.vRadius)
				l.Add (k.Key);
		}

		foreach (int i in l) {
			Destroy(pObj[i]);
			pObj[i] = null;
			pObj.Remove (i);
		}
		return pObj;
	}

	private static Dictionary<int,GameObject> removeAllObjects(Dictionary<int,GameObject> pObj)
	{

		foreach (KeyValuePair<int,GameObject> k in pObj) {
			Destroy(pObj[k.Key]);
			pObj.Remove (k.Key);
		}

		return pObj;

	}

	void manageObjects()
	{
		if (this.nearCorridors.Count > 0)
			this.nearCorridors = removeFarObjects (this.nearCorridors);
		List<int> l = getNearLocations (this.corridorLocations);
		foreach (int i in l) {
			if (!this.nearCorridors.ContainsKey (i))
				this.nearCorridors.Add (i, (GameObject) Instantiate (this.corridor, this.corridorLocations [i], Quaternion.identity));
		}

		if (this.nearDoors.Count > 0)
			this.nearDoors = removeFarObjects (this.nearDoors);
		l.Clear();
		l = null;
		l = getNearLocations (this.doorLocations);
		foreach(int i in l){
			if(!this.nearDoors.ContainsKey(i)){
				GameObject d = (GameObject) Instantiate (this.door, this.doorLocations [i], Quaternion.identity);
				if(i >= this.dirs.Length/2)
					d.transform.rotation = Quaternion.Euler(0,180,0);

				d.GetComponent<Door>().filePath = dirs[i];
				d.transform.name = dirs[i];
				d.transform.tag = "Navigate";
				d.GetComponentInChildren<TextMesh>().text = Path.GetFileName(dirs[i]);
				this.nearDoors.Add(i,d);
				

			}
		}

		if (this.nearShelfs.Count > 0)
			this.nearShelfs = removeFarObjects (this.nearShelfs);
		l.Clear ();
		l = null;
		l = getNearLocations (this.shelfLocations);

		foreach (int i in l) {
			if(!this.nearShelfs.ContainsKey(i))
			{
				GameObject s = (GameObject) Instantiate(this.shelf,this.shelfLocations[i],Quaternion.identity);
				for(int j = 0 ; j < this.filePerShelf && i*this.filePerShelf + j < this.files.Length; j++){
					s.transform.Find("File"+(j+1)).GetComponent<TextMesh>().text = Path.GetFileName(this.files[i*this.filePerShelf + j]);
				}
				this.nearShelfs.Add(i,s);

			}
		}


	}

	// Set Initial Position of Navigation and its child
	private static void setInitialPosition(){
		
		navigationTransformPosition = GameObject.Find ("Navigation").transform.position;
		
		mainCameraTransformPosition = GameObject.Find("Main Camera").transform.position;
		
	}

	// Fetch Raycasted Object Name. In case of exception the object is null.
	private static string onRaycasting(){
		
		// Get the head position and gaze direction from the Main Camera object
		Vector3 headPosition = GameObject.Find("Main Camera").transform.position;
		
		Vector3 gazeDirection = GameObject.Find("Main Camera").transform.forward;
		
		string gameObjectName = "";
		
		RaycastHit hitInfo;
		
		try{
			
			Physics.Raycast(headPosition, gazeDirection, out hitInfo);
			
			gameObjectName = hitInfo.collider.gameObject.name;
			
		} catch {
			
			gameObjectName = "null";
			
		}
		
		return gameObjectName;
		
	}

	// Get Initial Position of Navigation and its child
	private static void getInitialPosition(){

		/*float distance = Vector3.Distance (GameObject.Find ("Navigation").transform.position, navigationTransformPosition);

		while(distance > 1){

			GameObject.Find ("Navigation").transform.position =
				Vector3.Lerp (GameObject.Find ("Navigation").transform.position, navigationTransformPosition,
				              Time.deltaTime * 1.5f);

		} */

		GameObject.Find ("Navigation").transform.position = navigationTransformPosition;
		
		GameObject.Find("Main Camera").transform.position = mainCameraTransformPosition;
		
	}

	// Travel through Camera's Gaze Direction
	private static void onTravel(Quaternion gazeDirection, float navigation_speed){
		
		// Determine the travel vector based on the gaze direction and provided speed
		Vector3 travelVector = gazeDirection * Vector3.forward * navigation_speed;
		
		// Move the Navigation GameObject based on the travel vector
		GameObject.Find("Navigation").transform.Translate(travelVector);
		
	}

}
