﻿using UnityEngine;
using System.Collections;

public class Shelf : MonoBehaviour {

	// Use this for initialization
	public string filePath;
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
