﻿using UnityEngine;
using System.Collections;
using System.IO;
public class duplicateRoom : MonoBehaviour {
	// set Prefab
	public Transform room;
	string[] directories = Directory.GetDirectories("/Library");
	int roomNumber = 0;
	// Use this for initialization
	void Start () {
		// clone rooms
		for (int i = 0; i< directories.Length/2; i++) {
			Object folder = Instantiate(room, new Vector3(i*GameObject.Find("Floor").transform.localScale.x,0,0) + room.transform.position, Quaternion.identity);
			folder.name = "folder" + i;
			TextMesh text1 = GameObject.Find("folder" + i).transform.GetChild(0).gameObject.GetComponent<TextMesh>();
			TextMesh text2 = GameObject.Find("folder" + i).transform.GetChild(1).gameObject.GetComponent<TextMesh>();
			text1.text = directories[roomNumber];
			text2.text = directories[roomNumber+1];
			roomNumber = roomNumber + 2;
		}

		// hide original
		GameObject.Find ("Room").SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
